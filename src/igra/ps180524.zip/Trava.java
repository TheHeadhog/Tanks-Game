package igra;

import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class Trava extends Polje {

	public Trava(Mreza mreza) {
		super(mreza);
		setBackground(Color.GREEN);
	}

	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
	}
}
