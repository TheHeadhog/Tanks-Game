package igra;

import java.awt.Color;

@SuppressWarnings("serial")
public class Zid extends Polje {

	public Zid(Mreza mreza) {
		super(mreza);
		setBackground(Color.GRAY);
		// TODO Auto-generated constructor stub
	}

}
